// var
var var_x = 10;
console.log("Original value of var_x (var):", var_x); 

var_x = 20;
console.log("New value of var_x (var):", var_x); 

// let
let let_x = "Hello";
console.log("Value of let_x (let):", let_x); 

let_x = "World";
console.log("New value of let_x (let):", let_x); 

// const
const const_x = [1, 2, 3];
console.log("Value of const_x (const):", const_x); 

 
// const_x = [4, 5, 6];            // give error besause we can not assign new value to const varriable
console.log("New value of const_x (const):", const_x); 
